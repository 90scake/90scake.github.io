import React from 'react';
import PoundCakes from '../components/PoundCakes';

function PoundCakesPage() {
  return (
    <div className="pt-24">
      <PoundCakes />
    </div>
  );
}

export default PoundCakesPage;